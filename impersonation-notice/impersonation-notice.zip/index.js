"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);
var { createElement: h, useEffect, useState } = require("react");
var slotApi = require("@plugin-host");
var DEFAULT_RETURN_LABEL = "Back to platform";
var DEFAULT_ACTOR_ROLE_LABEL = "as Platform Admin";
var DEFAULT_BG_LIGHT = "#3b82f6";
var DEFAULT_FG = "#ffffff";
function looksLikeImpersonation(username) {
  return typeof username === "string" && username.includes("%");
}
function parseImpersonatedMailbox(username) {
  if (!looksLikeImpersonation(username)) return null;
  return username.split("%")[0] || null;
}
function pickString(value, fallback) {
  if (typeof value !== "string") return fallback;
  const trimmed = value.trim();
  return trimmed.length ? trimmed : fallback;
}
function ImpersonationBanner(props) {
  const username = props?.username;
  const mailbox = parseImpersonatedMailbox(username);
  const [busy, setBusy] = useState(false);
  const [cfg, setCfg] = useState({
    returnUrl: pickString(props?.returnUrl, ""),
    returnLabel: DEFAULT_RETURN_LABEL,
    actorRoleLabel: DEFAULT_ACTOR_ROLE_LABEL,
    bg: DEFAULT_BG_LIGHT,
    fg: DEFAULT_FG
  });
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const all = await slotApi.admin.getAllConfig().catch(() => null);
        if (cancelled) return;
        if (all && typeof all === "object") {
          setCfg((prev) => ({
            returnUrl: pickString(all.returnUrl, prev.returnUrl),
            returnLabel: pickString(all.returnLabel, DEFAULT_RETURN_LABEL),
            actorRoleLabel: pickString(all.actorRoleLabel, DEFAULT_ACTOR_ROLE_LABEL),
            bg: pickString(all.bannerBackground, DEFAULT_BG_LIGHT),
            fg: pickString(all.bannerForeground, DEFAULT_FG)
          }));
        }
      } catch (err) {
        slotApi.log.warn("impersonation-notice: could not read admin config", err);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);
  useEffect(() => {
    if (!mailbox) return;
    const drop = () => {
      try {
        fetch("/api/auth/session?all=true", {
          method: "DELETE",
          credentials: "same-origin",
          keepalive: true
        });
      } catch {
      }
    };
    window.addEventListener("pagehide", drop);
    window.addEventListener("beforeunload", drop);
    return () => {
      window.removeEventListener("pagehide", drop);
      window.removeEventListener("beforeunload", drop);
    };
  }, [mailbox]);
  if (!mailbox) return null;
  async function handleReturn() {
    if (busy) return;
    setBusy(true);
    try {
      await fetch("/api/auth/session?all=true", {
        method: "DELETE",
        credentials: "same-origin",
        keepalive: true
      });
    } catch {
    }
    if (cfg.returnUrl) {
      try {
        await slotApi.ui.openExternalUrl(cfg.returnUrl, "_blank");
      } catch (err) {
        slotApi.log.warn("impersonation-notice: openExternalUrl failed", err);
      }
    }
    setBusy(false);
  }
  return h(
    "div",
    {
      role: "status",
      "aria-live": "polite",
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: "16px",
        padding: "8px 16px",
        fontSize: "13px",
        fontWeight: 500,
        lineHeight: 1.4,
        width: "100%",
        boxSizing: "border-box",
        background: cfg.bg,
        color: cfg.fg
      }
    },
    h(
      "div",
      {
        style: {
          display: "inline-flex",
          alignItems: "center",
          gap: "8px",
          minWidth: 0
        }
      },
      h(
        "span",
        { "aria-hidden": "true", style: { fontSize: "14px", flexShrink: 0 } },
        "⚠"
      ),
      h(
        "span",
        {
          style: {
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap"
          }
        },
        "You are viewing ",
        h("strong", { style: { fontWeight: 700 } }, mailbox),
        " " + cfg.actorRoleLabel
      )
    ),
    cfg.returnUrl ? h(
      "button",
      {
        type: "button",
        onClick: handleReturn,
        disabled: busy,
        style: {
          flexShrink: 0,
          font: "inherit",
          fontWeight: 500,
          border: "1px solid currentColor",
          background: "transparent",
          color: "inherit",
          padding: "4px 12px",
          borderRadius: "6px",
          cursor: busy ? "progress" : "pointer",
          opacity: busy ? 0.6 : 0.95
        }
      },
      "← " + cfg.returnLabel
    ) : null
  );
}
function shouldShow(extraProps) {
  return looksLikeImpersonation(extraProps?.username);
}
var slots = {
  "app-top-banner": {
    component: ImpersonationBanner,
    shouldShow,
    order: 50
  }
};
async function activate(api) {
  api.log.info("Impersonation Notice plugin activated");
}
