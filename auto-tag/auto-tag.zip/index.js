"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks
});
module.exports = __toCommonJS(index_exports);
var rules = [];
var totalTagged = 0;
var pluginApi = null;
function buildRules(settings) {
  const out = [];
  if (settings.tagNewsletter !== false) {
    out.push({
      name: "Newsletter",
      keyword: "$newsletter",
      check: (email) => {
        const from = (email.from || "").toLowerCase();
        const subject = (email.subject || "").toLowerCase();
        return from.includes("newsletter") || from.includes("noreply") || from.includes("no-reply") || subject.includes("unsubscribe") || subject.includes("weekly digest") || subject.includes("monthly update");
      }
    });
  }
  if (settings.tagInvoice !== false) {
    out.push({
      name: "Invoice",
      keyword: "$invoice",
      check: (email) => {
        const subject = (email.subject || "").toLowerCase();
        return subject.includes("invoice") || subject.includes("receipt") || subject.includes("payment confirmation") || subject.includes("order confirmation") || subject.includes("billing statement");
      }
    });
  }
  if (settings.tagGithub !== false) {
    out.push({
      name: "GitHub",
      keyword: "$github",
      check: (email) => {
        const from = (email.from || "").toLowerCase();
        return from.includes("notifications@github.com") || from.includes("noreply@github.com");
      }
    });
  }
  return out;
}
async function activate(api) {
  pluginApi = api;
  rules = buildRules(api.plugin.settings || {});
  totalTagged = Number(await api.storage.get("totalTagged") || 0);
  if (rules.length === 0) {
    api.log.info("Auto Tag: no rules enabled");
    return;
  }
  api.log.info(`Auto Tag: ${rules.length} rule(s) active, ${totalTagged} previous match(es)`);
}
var hooks = {
  async onNewEmailReceived(notification) {
    if (!pluginApi || rules.length === 0) return;
    for (const rule of rules) {
      if (rule.check(notification)) {
        pluginApi.log.info(`Auto Tag: "${notification.subject}" matched rule "${rule.name}"`);
        totalTagged++;
        void pluginApi.storage.set("totalTagged", totalTagged);
        break;
      }
    }
  }
};
