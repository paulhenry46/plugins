"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks
});
module.exports = __toCommonJS(index_exports);
function parseDomains(input) {
  if (!input) return [];
  if (Array.isArray(input)) {
    return input.map((d) => normaliseDomain(String(d))).filter(Boolean);
  }
  return String(input).split(/[\s,;]+/).map(normaliseDomain).filter(Boolean);
}
function normaliseDomain(raw) {
  let d = String(raw).trim().toLowerCase();
  if (!d) return "";
  d = d.replace(/^\*\./, "");
  d = d.replace(/^https?:\/\//, "");
  d = d.replace(/\/.*$/, "");
  return d;
}
function hostnameFromHref(href) {
  try {
    const url = new URL(href);
    if (url.protocol !== "http:" && url.protocol !== "https:") return "";
    return url.hostname.toLowerCase();
  } catch {
    return "";
  }
}
function isTrusted(hostname, list) {
  if (!hostname) return false;
  for (const d of list) {
    if (!d) continue;
    if (hostname === d) return true;
    if (hostname.endsWith("." + d)) return true;
  }
  return false;
}
var pluginApi = null;
var cachedAdminDomains = [];
var adminFetched = false;
var adminFetchPromise = null;
var localTrusted = [];
function fetchAdminDomains() {
  if (adminFetched) return Promise.resolve(cachedAdminDomains);
  if (adminFetchPromise) return adminFetchPromise;
  adminFetchPromise = (async () => {
    try {
      const value = await pluginApi.admin.getConfig("trustedDomains");
      cachedAdminDomains = parseDomains(value);
    } catch (err) {
      pluginApi.log.warn("Could not load admin trusted-domains list", err);
      cachedAdminDomains = [];
    } finally {
      adminFetched = true;
    }
    return cachedAdminDomains;
  })();
  return adminFetchPromise;
}
async function getTrustedList() {
  const userDomains = parseDomains(pluginApi.plugin.settings.trustedDomainsCsv);
  const adminDomains = await fetchAdminDomains();
  return [.../* @__PURE__ */ new Set([...adminDomains, ...userDomains, ...localTrusted])];
}
async function addLocalTrust(domain) {
  if (!domain || localTrusted.includes(domain)) return;
  localTrusted.push(domain);
  await pluginApi.storage.set("localTrusted", localTrusted);
  pluginApi.toast.success(pluginApi.i18n?.t?.("trustedAdded") || "Added to trusted domains");
}
async function activate(api) {
  pluginApi = api;
  const stored = await api.storage.get("localTrusted");
  localTrusted = Array.isArray(stored) ? stored.slice() : [];
  fetchAdminDomains().catch(() => {
  });
  api.log.info("External Link Warning plugin activated");
}
var hooks = {
  async onBeforeExternalLink(ctx) {
    if (!pluginApi || !ctx?.href) return;
    const hostname = hostnameFromHref(ctx.href);
    if (!hostname) return;
    const trusted = await getTrustedList();
    if (isTrusted(hostname, trusted)) return;
    const proceed = await pluginApi.ui.confirm({
      title: "Open external link?",
      message: `You're about to visit ${hostname}.

${ctx.href}

This domain isn't on your trusted list \u2014 only continue if you recognise it.`,
      confirmLabel: "Continue",
      cancelLabel: "Cancel"
    });
    if (!proceed) return false;
    await pluginApi.ui.openExternalUrl(ctx.href, ctx.target || "_blank");
    if (pluginApi.plugin.settings.rememberLocalChoices !== false) {
      await addLocalTrust(hostname);
    }
    return false;
  }
};
