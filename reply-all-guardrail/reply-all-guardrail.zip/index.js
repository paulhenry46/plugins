"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks
});
module.exports = __toCommonJS(index_exports);
function normaliseEmail(addr) {
  if (!addr) return "";
  return String(addr).trim().toLowerCase();
}
function collectOutgoingRecipients(email, excludeAddresses) {
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const { field, list } of [
    { field: "To", list: email.to || [] },
    { field: "Cc", list: email.cc || [] },
    { field: "Bcc", list: email.bcc || [] }
  ]) {
    if (!Array.isArray(list)) continue;
    for (const a of list) {
      const n = normaliseEmail(a);
      if (!n || excludeAddresses.has(n) || seen.has(n)) continue;
      seen.add(n);
      out.push({ field, address: String(a).trim() });
    }
  }
  return out;
}
function collectReplyAllRecipients(originalEmail, excludeAddresses) {
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const { field, list } of [
    { field: "From", list: originalEmail.from || [] },
    { field: "To", list: originalEmail.to || [] },
    { field: "Cc", list: originalEmail.cc || [] }
  ]) {
    if (!Array.isArray(list)) continue;
    for (const entry of list) {
      const n = normaliseEmail(entry?.email);
      if (!n || excludeAddresses.has(n) || seen.has(n)) continue;
      seen.add(n);
      const display = entry?.name ? `${entry.name} <${entry.email}>` : String(entry?.email || "");
      out.push({ field, address: display });
    }
  }
  return out;
}
var pluginApi = null;
var myAddresses = /* @__PURE__ */ new Set();
var ADMIN_TTL_MS = 3e4;
var cachedAdminThreshold = null;
var cachedAdminAt = 0;
var adminFetchPromise = null;
function fetchAdminThreshold() {
  const fresh = Date.now() - cachedAdminAt < ADMIN_TTL_MS;
  if (fresh) return Promise.resolve(cachedAdminThreshold);
  if (adminFetchPromise) return adminFetchPromise;
  adminFetchPromise = (async () => {
    try {
      const v = await pluginApi.admin.getConfig("forceThreshold");
      const n = Number(v);
      cachedAdminThreshold = Number.isFinite(n) && n >= 1 ? Math.floor(n) : null;
    } catch (err) {
      pluginApi.log.warn("Could not load admin forceThreshold", err);
      cachedAdminThreshold = null;
    } finally {
      cachedAdminAt = Date.now();
      adminFetchPromise = null;
    }
    return cachedAdminThreshold;
  })();
  return adminFetchPromise;
}
function effectiveThreshold() {
  const userRaw = Number(pluginApi.plugin.settings.threshold);
  const userN = Number.isFinite(userRaw) && userRaw >= 1 ? Math.floor(userRaw) : 5;
  if (cachedAdminThreshold !== null && cachedAdminThreshold < userN) {
    return cachedAdminThreshold;
  }
  return userN;
}
function excludeSet() {
  return pluginApi.plugin.settings.excludeSelf === false ? /* @__PURE__ */ new Set() : myAddresses;
}
async function rememberMyAddress(addr) {
  const n = normaliseEmail(addr);
  if (!n || myAddresses.has(n)) return;
  myAddresses.add(n);
  await pluginApi.storage.set("myAddresses", [...myAddresses]);
}
function recipientsToMessage(recipients) {
  return recipients.map((r) => `[${r.field}] ${r.address}`).join("\n");
}
async function promptForRecipients(recipients, mode) {
  const isReplyAll = mode === "reply-all";
  const title = isReplyAll ? `Reply to all ${recipients.length} recipients?` : `Send to ${recipients.length} recipients?`;
  const body = isReplyAll ? `Replying to all would deliver this message to ${recipients.length} recipients. Confirm only if you intend to reach all of them.

${recipientsToMessage(recipients)}` : `${recipients.length} recipients are about to receive this message. Confirm only if you intend to send to all of them.

${recipientsToMessage(recipients)}`;
  return pluginApi.ui.confirm({
    title,
    message: body,
    confirmLabel: isReplyAll ? "Reply all" : "Send anyway",
    cancelLabel: "Cancel",
    danger: true
  });
}
var hooks = {
  async onBeforeReplyAll(ctx) {
    if (!ctx?.originalEmail || !pluginApi) return;
    await fetchAdminThreshold();
    const recipients = collectReplyAllRecipients(ctx.originalEmail, excludeSet());
    const threshold = effectiveThreshold();
    if (recipients.length < threshold) return;
    const ok = await promptForRecipients(recipients, "reply-all");
    if (!ok) {
      pluginApi.toast.info("Send cancelled");
      return false;
    }
  },
  async onBeforeEmailSend(email) {
    if (!email || !pluginApi) return;
    void rememberMyAddress(email.fromEmail);
    if (pluginApi.plugin.settings.warnOnSend === false) return;
    await fetchAdminThreshold();
    const recipients = collectOutgoingRecipients(email, excludeSet());
    const threshold = effectiveThreshold();
    if (recipients.length < threshold) return;
    const ok = await promptForRecipients(recipients, "send");
    if (!ok) {
      pluginApi.toast.info("Send cancelled");
      return false;
    }
  }
};
async function activate(api) {
  pluginApi = api;
  const stored = await api.storage.get("myAddresses") || [];
  myAddresses = new Set((Array.isArray(stored) ? stored : []).map(normaliseEmail).filter(Boolean));
  fetchAdminThreshold().catch(() => {
  });
  api.log.info("Reply-All Guardrail plugin activated");
}
