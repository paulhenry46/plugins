"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);
var { createElement: h, useEffect, useState, useRef, useCallback } = require("react");
var slotApi = require("@plugin-host");
var pluginApi = null;
var notes = {};
function NoteBanner() {
  return h(
    "div",
    {
      style: {
        padding: "6px 12px",
        background: "#eef2ff",
        color: "#3730a3",
        fontSize: "12px",
        display: "flex",
        alignItems: "center",
        gap: "6px"
      }
    },
    "\u{1F4DD}",
    h("span", null, "This email has a note attached.")
  );
}
function NotesSidebar(props) {
  const emailId = props?.email?.id || null;
  const [text, setText] = useState("");
  const [savedAt, setSavedAt] = useState(null);
  const [loaded, setLoaded] = useState(false);
  const debounceRef = useRef(null);
  const lastIdRef = useRef(null);
  useEffect(() => {
    if (!emailId) {
      setText("");
      setSavedAt(null);
      setLoaded(true);
      lastIdRef.current = null;
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const stored = await slotApi.storage.get("notes") || {};
        if (cancelled) return;
        const entry = stored && typeof stored === "object" ? stored[emailId] : null;
        setText(entry?.text || "");
        setSavedAt(entry?.updatedAt || null);
      } catch (err) {
        slotApi.log.warn("quick-notes: could not load notes", err);
      } finally {
        if (!cancelled) {
          setLoaded(true);
          lastIdRef.current = emailId;
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [emailId]);
  const persist = useCallback(async (nextText) => {
    if (!emailId) return;
    try {
      const stored = await slotApi.storage.get("notes") || {};
      const map = stored && typeof stored === "object" ? { ...stored } : {};
      const trimmed = nextText.trim();
      const settings = slotApi.plugin?.settings || {};
      const maxNotes = Number(settings.maxNotes) || 100;
      if (!trimmed) {
        delete map[emailId];
      } else {
        map[emailId] = { text: nextText, updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
        const ids = Object.keys(map);
        if (ids.length > maxNotes) {
          const sorted = ids.map((id) => ({ id, t: map[id]?.updatedAt || "" })).sort((a, b) => a.t < b.t ? -1 : a.t > b.t ? 1 : 0);
          const drop = sorted.slice(0, ids.length - maxNotes);
          for (const { id } of drop) delete map[id];
        }
      }
      await slotApi.storage.set("notes", map);
      setSavedAt(map[emailId]?.updatedAt || null);
    } catch (err) {
      slotApi.log.warn("quick-notes: save failed", err);
    }
  }, [emailId]);
  const onChange = useCallback((ev) => {
    const next = ev.target.value;
    setText(next);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      void persist(next);
    }, 500);
  }, [persist]);
  useEffect(() => {
    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current);
        debounceRef.current = null;
      }
    };
  }, [emailId]);
  if (!emailId) {
    return h(
      "div",
      { style: { padding: "12px", fontSize: "13px", color: "#64748b" } },
      h("div", { style: { fontWeight: 600, marginBottom: "4px" } }, "Quick Notes"),
      "Open an email to add a note."
    );
  }
  return h(
    "div",
    {
      style: {
        padding: "12px",
        fontSize: "13px",
        display: "flex",
        flexDirection: "column",
        gap: "6px"
      }
    },
    h(
      "div",
      {
        style: {
          fontWeight: 600,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "baseline"
        }
      },
      h("span", null, "Quick Notes"),
      savedAt ? h(
        "span",
        { style: { fontSize: "11px", color: "#94a3b8", fontWeight: 400 } },
        `saved ${new Date(savedAt).toLocaleTimeString()}`
      ) : null
    ),
    h("textarea", {
      value: loaded ? text : "",
      onChange,
      placeholder: "Jot a note for this email\u2026",
      rows: 8,
      style: {
        width: "100%",
        boxSizing: "border-box",
        font: "inherit",
        padding: "8px",
        borderRadius: "6px",
        border: "1px solid #cbd5e1",
        resize: "vertical",
        background: "#ffffff",
        color: "#0f172a"
      }
    }),
    h(
      "div",
      { style: { fontSize: "11px", color: "#94a3b8" } },
      "Notes auto-save half a second after you stop typing."
    )
  );
}
function shouldShowBanner(extraProps) {
  if (!pluginApi) return false;
  if (pluginApi.plugin.settings.showBanner === false) return false;
  const email = extraProps?.email;
  if (!email?.id) return false;
  return !!notes[email.id];
}
var slots = {
  "email-banner": {
    component: NoteBanner,
    shouldShow: shouldShowBanner,
    order: 80
  },
  "email-detail-sidebar": {
    component: NotesSidebar,
    order: 20
  }
};
var hooks = {
  // Refresh the in-memory cache when an email is opened so the banner gate
  // is accurate even after edits from the sidebar slot.
  async onEmailOpen() {
    if (!pluginApi) return;
    const stored = await pluginApi.storage.get("notes");
    notes = stored && typeof stored === "object" ? stored : {};
  }
};
async function activate(api) {
  pluginApi = api;
  const stored = await api.storage.get("notes");
  notes = stored && typeof stored === "object" ? stored : {};
  api.log.info(`Quick Notes plugin activated (${Object.keys(notes).length} note(s) stored)`);
}
