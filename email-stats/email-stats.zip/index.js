"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);
var { createElement: h, useEffect, useState, useCallback } = require("react");
var slotApi = require("@plugin-host");
var POLL_MS = 3e3;
function StatsWidget() {
  const [stats, setStats] = useState({ opened: 0, sent: 0, received: 0 });
  const [loaded, setLoaded] = useState(false);
  const refresh = useCallback(async () => {
    try {
      const stored = await slotApi.storage.get("lifetime");
      if (stored && typeof stored === "object") {
        setStats({
          opened: Number(stored.opened) || 0,
          sent: Number(stored.sent) || 0,
          received: Number(stored.received) || 0
        });
      }
    } catch (err) {
      slotApi.log.warn("email-stats: could not read storage", err);
    } finally {
      setLoaded(true);
    }
  }, []);
  useEffect(() => {
    void refresh();
    const id = setInterval(() => {
      void refresh();
    }, POLL_MS);
    const onFocus = () => {
      void refresh();
    };
    window.addEventListener("focus", onFocus);
    return () => {
      clearInterval(id);
      window.removeEventListener("focus", onFocus);
    };
  }, [refresh]);
  const today = (/* @__PURE__ */ new Date()).toLocaleDateString();
  const row = (label, value) => h(
    "div",
    {
      style: {
        display: "flex",
        justifyContent: "space-between",
        padding: "2px 0"
      }
    },
    h("span", { style: { color: "var(--color-muted-foreground)" } }, label),
    h("span", { style: { fontWeight: 600, fontVariantNumeric: "tabular-nums" } }, value)
  );
  return h(
    "div",
    { style: { padding: "12px", fontSize: "13px", lineHeight: 1.4 } },
    h(
      "div",
      { style: { fontWeight: 600, marginBottom: "8px" } },
      `Email Stats \u2014 ${today}`
    ),
    !loaded ? h("div", { style: { color: "var(--color-muted-foreground)" } }, "Loading\u2026") : h(
      "div",
      null,
      row("Opened", stats.opened),
      row("Sent", stats.sent),
      row("Received", stats.received)
    )
  );
}
var slots = {
  "sidebar-widget": {
    component: StatsWidget,
    order: 10
  }
};
var pluginApi = null;
var lifetime = { opened: 0, sent: 0, received: 0 };
async function bump(field) {
  if (!pluginApi) return;
  lifetime[field]++;
  void pluginApi.storage.set("lifetime", lifetime);
}
var hooks = {
  onEmailOpen() {
    if (pluginApi?.plugin.settings.trackOpens === false) return;
    void bump("opened");
  },
  onAfterEmailSend() {
    if (pluginApi?.plugin.settings.trackSent === false) return;
    void bump("sent");
  },
  onNewEmailReceived() {
    void bump("received");
  }
};
async function activate(api) {
  pluginApi = api;
  const stored = await api.storage.get("lifetime") || null;
  if (stored && typeof stored === "object") {
    lifetime = {
      opened: Number(stored.opened) || 0,
      sent: Number(stored.sent) || 0,
      received: Number(stored.received) || 0
    };
  }
  api.log.info(
    `Email Stats activated (lifetime: opened=${lifetime.opened} sent=${lifetime.sent} received=${lifetime.received})`
  );
}
