"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);
var { createElement: h, useEffect, useState } = require("react");
var slotApi = require("@plugin-host");
var INTENT_KEY = "scheduleIntent";
var QUEUE_KEY = "queue";
var COUNT_KEY = "scheduledCount";
var DELAY_LABELS = {
  "30m": "30 minutes",
  "1h": "1 hour",
  "2h": "2 hours",
  "4h": "4 hours",
  "tomorrow-9am": "Tomorrow at 9:00 AM"
};
function computeReleaseAt(delay) {
  const now = /* @__PURE__ */ new Date();
  switch (delay) {
    case "30m":
      return new Date(now.getTime() + 30 * 6e4);
    case "1h":
      return new Date(now.getTime() + 60 * 6e4);
    case "2h":
      return new Date(now.getTime() + 2 * 60 * 6e4);
    case "4h":
      return new Date(now.getTime() + 4 * 60 * 6e4);
    case "tomorrow-9am": {
      const next = new Date(now);
      next.setDate(next.getDate() + 1);
      next.setHours(9, 0, 0, 0);
      return next;
    }
    default:
      return new Date(now.getTime() + 60 * 6e4);
  }
}
function SendLaterButton() {
  const [armed, setArmed] = useState(null);
  const settings = slotApi.plugin?.settings || {};
  const defaultDelay = settings.defaultDelay || "1h";
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const intent = await slotApi.storage.get(INTENT_KEY);
      if (!cancelled && intent && intent.delay) setArmed(intent);
    })();
    return () => {
      cancelled = true;
    };
  }, []);
  async function arm() {
    const releaseAt = computeReleaseAt(defaultDelay);
    const human = DELAY_LABELS[defaultDelay] || defaultDelay;
    const proceed = await slotApi.ui.confirm({
      title: "Schedule next send?",
      message: `When you click Send, this message will be held and released in ${human} (around ${releaseAt.toLocaleString()}).

Until then it lives in plugin storage \u2014 clear it with the same Send Later button.`,
      confirmLabel: "Schedule it",
      cancelLabel: "Cancel"
    });
    if (!proceed) return;
    const intent = { delay: defaultDelay, releaseAt: releaseAt.toISOString() };
    await slotApi.storage.set(INTENT_KEY, intent);
    setArmed(intent);
    if (settings.showConfirmation !== false) {
      slotApi.toast.success(`Next send will be held until ${releaseAt.toLocaleString()}`);
    }
  }
  async function disarm() {
    await slotApi.storage.set(INTENT_KEY, null);
    setArmed(null);
    slotApi.toast.info("Send Later cancelled \u2014 next send goes immediately");
  }
  const label = armed ? `\u23F0 Send Later: ${new Date(armed.releaseAt).toLocaleTimeString()}` : "\u23F0 Send Later";
  return h(
    "button",
    {
      type: "button",
      onClick: armed ? disarm : arm,
      title: armed ? "Click to cancel the scheduled hold" : `Schedule next send in ${DELAY_LABELS[defaultDelay] || defaultDelay}`,
      style: {
        font: "inherit",
        padding: "6px 10px",
        borderRadius: "6px",
        border: armed ? "1px solid #f59e0b" : "1px solid #cbd5e1",
        background: armed ? "#fffbeb" : "#f8fafc",
        color: armed ? "#92400e" : "inherit",
        cursor: "pointer"
      }
    },
    label
  );
}
var slots = {
  "composer-toolbar": {
    component: SendLaterButton,
    order: 90
  }
};
var pluginApi = null;
var hooks = {
  async onBeforeEmailSend(outgoing) {
    if (!pluginApi) return;
    const intent = await pluginApi.storage.get(INTENT_KEY);
    if (!intent || !intent.delay || !intent.releaseAt) return;
    const queue = await pluginApi.storage.get(QUEUE_KEY) || [];
    const list = Array.isArray(queue) ? queue : [];
    list.push({
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      releaseAt: intent.releaseAt,
      delay: intent.delay,
      email: outgoing
    });
    await pluginApi.storage.set(QUEUE_KEY, list);
    await pluginApi.storage.set(INTENT_KEY, null);
    const count = Number(await pluginApi.storage.get(COUNT_KEY) || 0) + 1;
    await pluginApi.storage.set(COUNT_KEY, count);
    try {
      await pluginApi.http.post("/api/send-later", {
        releaseAt: intent.releaseAt,
        email: outgoing
      });
    } catch (err) {
      pluginApi.log.debug("send-later: no host endpoint (storage-only mode)", err);
    }
    pluginApi.toast.success(
      `Send Later: held until ${new Date(intent.releaseAt).toLocaleString()}. ${list.length} message(s) in the queue.`
    );
    return false;
  },
  onComposerOpen() {
    pluginApi?.log.debug("Composer opened; Send Later is available");
  }
};
async function activate(api) {
  pluginApi = api;
  const defaultDelay = api.plugin.settings.defaultDelay || "1h";
  const queue = await api.storage.get(QUEUE_KEY) || [];
  const list = Array.isArray(queue) ? queue : [];
  const scheduledSends = Number(await api.storage.get(COUNT_KEY) || 0);
  const due = list.filter((e) => new Date(e.releaseAt).getTime() <= Date.now());
  if (due.length > 0) {
    api.toast.warning(
      `Send Later: ${due.length} held message(s) became due while the app was closed. Review them in plugin storage and resend manually.`
    );
  }
  api.log.info(
    `Send Later activated (default: ${DELAY_LABELS[defaultDelay] || defaultDelay}, ${list.length} held, ${scheduledSends} historical)`
  );
}
