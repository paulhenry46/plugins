"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);
var { createElement: h, useState } = require("react");
function MyWidget(props) {
  const [count, setCount] = useState(0);
  return h(
    "div",
    { style: { padding: "12px", fontSize: "13px" } },
    h("div", { style: { fontWeight: 600, marginBottom: "8px" } }, "My Plugin"),
    h(
      "button",
      {
        type: "button",
        onClick: () => setCount((c) => c + 1),
        style: {
          font: "inherit",
          padding: "6px 10px",
          borderRadius: "6px",
          border: "1px solid #cbd5e1",
          background: "#f8fafc",
          cursor: "pointer"
        }
      },
      `Clicked ${count} times`
    ),
    props?.email ? h(
      "div",
      { style: { marginTop: "8px", color: "#64748b" } },
      `Current email: ${props.email.subject || "(no subject)"}`
    ) : null
  );
}
var slots = {
  // Pick a slot name from SlotName in lib/plugin-types.ts:
  //   toolbar-actions, app-top-banner, email-banner, email-footer,
  //   composer-toolbar, composer-sidebar, composer-sidebar-right,
  //   sidebar-widget, email-detail-sidebar, settings-section,
  //   context-menu-email, navigation-rail-bottom,
  //   calendar-event-actions, admin-plugin-page
  "sidebar-widget": {
    component: MyWidget,
    // shouldShow runs in the BACKGROUND iframe with the host's extraProps.
    // Return false to skip mounting the slot iframe entirely.
    shouldShow: () => true,
    order: 100
  }
};
var hooks = {
  onAppReady() {
    console.info("[my-plugin] App is ready");
  },
  onEmailOpen(email) {
    console.info("[my-plugin] Email opened:", email?.subject);
  }
  // Intercept hooks may return a Promise. Return `false` to cancel.
  // async onBeforeEmailSend(draft) {
  //   const ok = await api.ui.confirm({ title: 'Send?', message: '...' });
  //   return ok ? undefined : false;
  // },
};
async function activate(api) {
  if (api.plugin.settings.enabled === false) {
    api.log.info("Plugin disabled by user settings");
    return;
  }
  const runCount = Number(await api.storage.get("runCount") || 0) + 1;
  await api.storage.set("runCount", runCount);
  api.log.info(`Plugin activated (run ${runCount})`);
}
