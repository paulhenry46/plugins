"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);
var { createElement: h, useState } = require("react");
var slotApi = require("@plugin-host");
function JitsiAddButton(props) {
  const [busy, setBusy] = useState(false);
  const eventTitle = props?.eventData?.title || "meeting";
  const setVirtualLocation = props?.setVirtualLocation;
  async function handleClick() {
    if (busy) return;
    setBusy(true);
    try {
      const data = await slotApi.http.post("/api/jitsi", { eventTitle });
      const url = data?.url;
      if (!url) throw new Error("No url in response");
      if (typeof setVirtualLocation === "function") {
        await setVirtualLocation(url);
        slotApi.toast.success("Jitsi meeting added to event");
      } else {
        await slotApi.ui.alert({
          title: "Jitsi meeting created",
          message: url
        });
      }
    } catch (err) {
      const message = err && err.message ? err.message : String(err);
      slotApi.toast.error(`Could not create Jitsi meeting: ${message}`);
    } finally {
      setBusy(false);
    }
  }
  return h(
    "button",
    {
      type: "button",
      onClick: handleClick,
      disabled: busy,
      style: {
        font: "inherit",
        padding: "6px 10px",
        borderRadius: "6px",
        border: "1px solid #cbd5e1",
        background: "#f8fafc",
        cursor: busy ? "progress" : "pointer"
      }
    },
    busy ? "Generating…" : "📹 Add Jitsi Meeting"
  );
}
var slots = {
  "calendar-event-actions": {
    component: JitsiAddButton,
    order: 10
  }
};
async function activate(api) {
  api.log.info("Jitsi Meet plugin activated");
}
